# ST2 — v30g loss ledger and directed macro search

**Status: COMPLETE. Best finalist `best` = `p1_1f06c7629af3b3`; all-orders 5.144319849358e-5, MC3 mean 5.089778e-5. All ST2 jobs have exited.**

## v30g loss ledger

Base `MAIN/v30g`: second **4.505332173166e-5** + cubic **1.115093648551e-5** = **5.620425821717e-5**, |c1|=2.40548e-19. Sparse all-orders **5.686889551657e-5**, acceptance **0.504953423755**, exp(−A1)=0.505192472978. 194 CX, R48. Its equivalence to COMP29’s seed through cubic order is accepted; the earlier floating-point-sized ST2 “gain” was not a physical improvement.

Ownership is disjoint and follows each physical lifetime. B/C starts at its final resource initialization; A starts at its final encoder initialization, including measured reuse. Round is native t≥48. Prefix operations include cultivation, blue checks, transfers and final T†; prefix idles are the remaining pre-round idles. Data wait starts after each output wire’s last prefix CX: q0=40, q20=40, q7=39, q10=39, q3=33, q22=44, q21=40. This includes wait while other prefix/prep work continues. Init maps and channel counts are in `ledger_cubic.json`; no existing idle gap crosses a category.

Each row is a complete conditional-loss counterfactual. “No” removes only that region’s noise; “only” leaves only that region noisy. Removal gains overlap and must not be added. These are noise prices, not physically realizable circuits. Values in this table are ×10⁻⁶.

| Region | No region: cubic | Only region: cubic | No region: all orders | Only region: all orders | All-orders removal gain |
|---|---:|---:|---:|---:|---:|
| Prefix internal operations | 51.644597 | 0.192815 | 52.048708 | 0.193690 | 4.820187 |
| Prefix internal idles | 47.850850 | 0.405088 | 48.035821 | 0.432343 | 8.833075 |
| Data wait | 45.714122 | 0.284275 | 45.979861 | 0.292107 | 10.889034 |
| B/C resource | 46.904570 | 3.577823 | 47.392025 | 3.578803 | 9.476870 |
| A preparation | 42.211393 | 1.596469 | 42.637276 | 1.596664 | 14.231620 |
| Round and readout | 20.523756 | 28.711730 | 20.970384 | 28.712171 | 35.898512 |

### Five largest fault-pair mechanism classes

| Class | Pair contribution | Largest individual pair |
|---|---:|---|
| round × round | 2.8840000000e-05 | 1.111111e-07: L405 idle Y@q0 t=50..50 + L406 idle Z@q20 t=50..50 |
| BC × BC | 3.5080007899e-06 | 2.217782e-07: L313 idle X@q4 t=42..45 + L362 idle X@q17 t=46..46 |
| A × data_wait | 2.7651587812e-06 | 1.769504e-07: L279 idle Z@q0 t=40..47 + L356 gate2 IZ@q8,14 t=45 |
| A × BC | 1.8888888889e-06 | 2.222222e-08: L241 gate1 Y@q26 t=36 + L337 gate2 IZ@q14,8 t=43 |
| A × prefix_idles | 1.7082576270e-06 | 2.085968e-07: L166 idle X@q4 t=18..36 + L355 gate2 IY@q1,2 t=45 |

### Leading cross terms

Inclusion–exclusion over all 64 region subsets separates interactions through cubic order. These signed components include conditional-denominator corrections and sum to the full cubic loss. Pair and cubic columns below are ×10⁻⁶.

| Interaction | Pair part | Cubic part | Total |
|---|---:|---:|---:|
| data_wait × A | 2.765159 | 0.615801 | 3.380959 |
| prefix_idles × A | 1.708258 | 0.373270 | 2.081528 |
| BC × A | 1.888889 | 0.147528 | 2.036417 |
| prefix_idles × data_wait | 0.773126 | 0.983337 | 1.756463 |
| A × round | 1.484444 | 0.239381 | 1.723825 |
| BC × round | 1.092800 | 0.197820 | 1.290621 |
| prefix_ops × prefix_idles | 0.359788 | 0.796934 | 1.156723 |
| data_wait × round | 0.000000 | 0.884810 | 0.884810 |

The five largest three-region classes first appear at cubic order:

- data_wait × A × round: 5.0398791801e-07.
- data_wait × BC × round: 4.4766155877e-07.
- data_wait × BC × A: 4.3447704601e-07.
- prefix_ops × prefix_idles × data_wait: 4.1233215301e-07.
- prefix_idles × data_wait × round: 4.1043510586e-07.

The specific q7 X idle t20–23 × q20 Y wait t40–46 pair is **7.73125600632e-7**. A-only loss is only 1.596664e-6, while removing A noise saves 1.423162e-5: interactions dominate its price. Round-only loss is 2.871217e-5; both prefix-internal idles and later data wait remain material targets.

### Ledger verification

All 13 base/only/no-region cases have complete 72-key sparse all-orders checks and categorical Fourier cubic contractions. All 13 are independently reproduced by exact2 pair/triple enumeration, agreeing at the CLI’s printed precision (`ledger_reference_audit.json`). The enumeration prunes only algebraically impossible accepted detector parities and omits zero-probability channels; surviving arithmetic and the exact2 model are unchanged. Five only-region cases and the no-prefix-operations case also completed the unpruned CLI. The slow unpruned sweep was superseded by the completed parity-pruned sweep.

The original 64-detector CLI emits an integer-cast warning. An invertible detector-row/order transform preserves every fault signature, rotation, decoder and acceptance condition while keeping accepted masks in exactly representable low bits. `ledger_v30g.detorder.validation.json` records the proof checks. A coarse global time cut was rejected because it mislabeled interleaved A/B/C prep as prefix. No values from that abandoned split are used.

## Best finalist

**`best.qasm` / `best.json` = `p1_1f06c7629af3b3`.** Source: SEPBC’s `v30/sensitivity_tail` R45 schedule, then ST2’s composed echoed parity checks and known-state watch. **205 CX, R45, native depth48.** B→C verification remains immediately before B→data coupling. Relative to v30g, the round starts 3 ticks earlier and protection uses existing idle slots. Relative to v25k, the circuit retains FRESH’s 57-CX correlated rank-three B/C resource and the existing blue check/terminal exchange.

| Quantity | Verified value |
|---|---:|
| All-orders 1−F | **5.144319849358e-05** |
| All-orders acceptance | 0.500961772549 |
| exp(−A1) | 0.501023173435 |
| Exact second order | 4.302921903255e-05 |
| Exact cubic increment | 8.047477171943e-06 |
| Exact through third order | 5.107669620449e-05 |
| First-order loss | 2.665e-19 |
| Judge 1e6 | PASS; acceptance 0.500364 |
| Actual zebra seconds/1e6 | 4.707 |
| XTIM speed | FAST; 6.841 s/1e6 |
| MC 1e8, seeds 0/1000/2000 | 5.179097e-05 / 5.021205e-05 / 5.069032e-05 |
| MC3 mean | **5.089778e-05** |

All-orders improvement over v30g: **9.54071%**. The original4.8e-5 success screen was not reached. The all-orders expectation remains above the reported leader’s 5.067e-5; the MC mean does not establish a reversal of that ordering.

Protection windows below include initialization and readout; the two CXs occupy start+1 and end−1. Every added operation fits an original idle tick.

| Protected cell / helper | Axis | Window |
|---|---|---|
| q10 / q11 | X | 19–29 |
| q7 / q13 | X | 20–23 |
| q0 / q6 | Z | 34–41 |
| q20 / q19 | X | 18–33 |
| q20 / q26 | Z | 20–31 |
| q10 / q16 | X | 21–27 |
| q4 / q5 | X | 18–33 |
| q15 / q21 | X | 20–28 |

An additional deterministic Z watch is on q16 at t30. Protection of q10 before its transfer is ancillary-storage protection; cells4,15,16 are tracked as temporary data-storage locations. Helpers must be virgin or released, with their next use compatible with reinitialization. Measured-reuse noise is included by the judge model.

The finalist has 66 detectors. The raw cubic batching routine overflows its signed64-bit detector input; this is a diagnostic limitation, not a judge failure. `reference_cubic.py` appends the last record twice (zero parity) to reference-only detector rows and permutes them. All noise, rotation, decoder and per-fault permutation identities are asserted. The complete cubic contraction and independently pruned exact2 enumeration agree within **4.26e-18**. The submitted artifact is unchanged; sparse all-orders and judge/MC use its original detector rows. Full receipts: `best.verify.json`, `p1_1f06c7629af3b3.cubic.json`, and the compressed `.mc3.log.xz`.

## Move set, repair, and population

Whole-window operators: mixed per-wire ASAP/ALAP objectives; early measurement/release objectives; A/wait joint retiming; commuting-CX window rewrites; complete echoed parity windows; known-state idle detectors; and simultaneous readout-edge rewrites with detector-parity transport. Further beams enumerate maximal helper-free subwindows and then temporary data trajectories.

Repair preserves native folding and precedence, excludes shared-cell collisions, checks nearest-neighbour CXs, sizes the record register, and transports detector parities when readout edges change. Reset-based echo initialization returns the helper to its specified basis; no random-MX pivot initialization is introduced. Every candidate gets exact noiseless/c1 and acceptance-proxy screening, followed by full all-orders pricing. Acceptance is a gate, never a reward. Worse candidates retain explicit diversity slots.

| Search | Evaluations | All-orders-valid and acceptance-eligible | Generations |
|---|---:|---:|---:|
| Directed macro population | 148 | 119 | 6 |
| Released-helper beam | 158 | 148 | 4 |
| Temporary-trajectory beam | 90 | 57 | 3 |
| Cubic-gradient timing windows | 46 | 45 | standalone |
| **Total** | **442** | **369** | **13 beam/evolution generations** |

210 child evaluations beat their resolved parent by more than 1e-13 in all-orders loss; this includes distinct schedules with the same protection topology. The first population records 27 improving accepted moves. The final ranking is by all-orders alone. Family traces and generation fronts are compressed under each run directory; `search_totals.json` summarizes the totals.

Gated loss/runtime comparison (runtime is actual zebra 1e6):

| Candidate | All-orders loss | Acceptance proxy | Seconds | CX |
|---|---:|---:|---:|
| best | 5.14431984936e-5 | 0.50102317 | 4.707 | 205 |
| p0_56b3503ba1f17d | 5.30524986919e-5 | 0.52710381 | 4.251 | 195 |
| g4_b7024a4a846918 | 5.45689832650e-5 | 0.53076223 | 5.893 | 193 |
| v30g | 5.68688955166e-5 | 0.50519247 | 3.2 inherited | 194 |

COMP29 and SEPBC seeds, plus WAITPROT’s corrected native-tick q7/q4 gadgets, were included. BCPOL and BCFB directories were rechecked: no better fully verified v30f seed was available at the seeding cut; BCPOL’s later best cubic screen was 5.99197e-5 and BCFB’s A campaign remained in progress. Their source files were read only.

Negative result: all 46 gradient-guided timing proposals were priced; the best was 5.90223e-5 and none improved its seed. The surrogate only differentiated existing idle channels; retiming creates previously absent gaps, so those slopes miss new exposure. All-orders pricing rejected the apparent surrogate gains. Broad timing changes were likewise weaker than composed native protection windows in this search.

## Verified versus inferred

Verified: complete v30g noise ledger; 13 independent sparse and cubic/enumeration comparisons; 442 search evaluations; final nearest-neighbour/noiseless/singles/acceptance checks; original judge 1e6; XTIM FAST and actual zebra runtime; all-orders expectation and three 1e8-shot seeds. The final circuit and metadata hashes are recorded in `best.verify.json`. All ST2 compute jobs on zebra and sunfish exited; temporary resource suspensions were resumed and collected. No credentials, submissions, commits, pushes, or subagents were used.

Inferred limits: the ledger’s noiseless-region prices are not achievable hardware bounds, the proposal families do not establish global optimality, and the server runtime is not measured here. Unpruned cubic CLI above 64 detectors is outside its integer-mask scope; the final cubic diagnostic uses the explicitly verified representation and exact parity pruning described above.

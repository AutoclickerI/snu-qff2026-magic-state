**New gated finalist `knapsack/early/drop_Z20_mz5`: all-orders 5.138631919778e-05, acceptance 0.502117747; judge PASS, acceptance 0.501729, 3.204s/1e6; XTIM FAST 3.944s/1e6; MC3 pending.**

# ST2 — acceptance knapsack and protection composition

**Status: RUNNING. Base MAIN/v32p; all-orders 5.144319849358e-5, acceptance0.500961772549. Required candidate acceptance floor0.5005.**

## Acceptance prices

46 completed prices are locally collected; 44 have all-orders values. Unfinished remote prices are not counted. Every detector row, eight complete echo gadgets, the q16 watch, known-zero measurements, measured initialization forms, physical blue branches, and A/B/C detector subsets are being priced.

Selected completed marginal prices below are complete-circuit all-orders differences relative to v32p. Positive acceptance is recovered by removing/replacing the element. They are not additive physical attributions.

| Removed/replaced element | Loss increase | Acceptance recovered | Verified status |
|---|---:|---:|---|
| `knapsack/prices/det_27` | +3.070809069e-12 | +0.000002280 | all-orders |
| `knapsack/prices/det_03` | +2.268907276e-09 | +0.000639211 | all-orders |
| `knapsack/prices/det_26` | +2.838498282e-10 | +0.000003435 | all-orders |
| `knapsack/prices/det_24` | +4.335953609e-10 | +0.000002762 | all-orders |
| `knapsack/prices/det_30` | +4.356703473e-10 | +0.000002291 | all-orders |
| `knapsack/prices/det_00` | +2.011788693e-07 | +0.001017955 | all-orders |
| `knapsack/prices/det_29` | +9.933867377e-10 | +0.000004804 | all-orders |
| `knapsack/prices/det_34` | +1.634412232e-07 | +0.000639531 | all-orders |
| `knapsack/prices/det_25` | +1.380514233e-09 | +0.000004095 | all-orders |
| `knapsack/prices/det_35` | +3.403000392e-07 | +0.000643639 | all-orders |
| `knapsack/prices/det_37` | +4.576624681e-07 | +0.000012090 | all-orders |
| `knapsack/prices/det_23` | +2.022042517e-07 | +0.000001035 | all-orders |

## Search and repair

Marginal log-acceptance knapsacks use conflict constraints between alternative edits, followed by full all-orders repricing of every composition. Other operators include shortened/split echo intervals, sequential use of measured helpers with parity transport, checked-Z preparations, zero-width-aware cubic-gradient timing proposals, and protection subsets on SEPBC R44/R45 seeds. BCFB’s new A witness is ported with full-prefix timing repair at fixed R45. Acceptance is a hard gate; it is not a ranking reward.

The previous timing surrogate missed newly created idle gaps. This pass uses SEPBC’s explicit zero-probability gap channels before differentiating; the on-disk judge/noise model remains unchanged. The proposed circuits still receive full all-orders evaluation.

Sparse factor-cache experiment reproduced the baseline exactly but obtained zero cache hits before its memory cap; it is not used for search ranking.

## Verification and resources

All-orders sparse evaluation supports these Python-integer detector masks. Cubic diagnostics above the raw64-bit limit use ST2’s proven reference-only ordering. Candidates that lose deterministic noiseless detectors are rejected. Finalists require the original judge1e6, actual zebra runtime≤20s, XTIM FAST, and three1e8-shot seeds.

The initial zebra pool was paused by owned PID when host load rose; its remaining work was moved to owl after MAIN redraws exited at23:25. All completed prices were preserved. No submissions, commits, pushes, credentials, or subagents. Active jobs will be collected before completion.

Prior verified v30g loss ledger, v32p delivery, and442-evaluation search are preserved in `report_v32p.md.xz`.
